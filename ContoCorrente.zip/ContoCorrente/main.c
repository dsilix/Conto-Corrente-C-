#include <stdio.h>
#include <stdlib.h>
#include "libreria.h"


//PROTOTIPI
void registra(correntista*, int*);
void movimento(correntista*,listaMovimenti*,int*);
void visualizzaMovimenti(correntista *,int *);
void menubanca();

int main() {
    menubanca();
}





